username = "GISD26WS"
password = "GISD26WS"
dsn = "192.168.3.81/HKE2020041501"
port = 1521
